# Goldiss Chat — Flutter UI

Implémentation Flutter complète des écrans d'authentification et d'onboarding.

## Structure des fichiers

```
lib/
├── main.dart                      # Point d'entrée + routing
├── theme/
│   └── app_theme.dart             # Couleurs, thème Material3
├── widgets/
│   ├── goldiss_logo.dart          # Logo SVG custom (GoldissLogo, GoldissLogoSmall)
│   └── primary_button.dart        # Bouton gradient réutilisable
└── screens/
    ├── splash_screen.dart         # Écran splash animé
    ├── onboarding_screen.dart     # 3 slides d'onboarding
    ├── login_screen.dart          # Écran de connexion
    └── register_screen.dart       # Écran d'inscription
```

## Fonts requises

Télécharge et place dans `assets/fonts/` :
- **Quicksand** : https://fonts.google.com/specimen/Quicksand
  - Quicksand-Regular.ttf, Quicksand-SemiBold.ttf, Quicksand-Bold.ttf
- **Plus Jakarta Sans** : https://fonts.google.com/specimen/Plus+Jakarta+Sans
  - PlusJakartaSans-Regular.ttf, PlusJakartaSans-Medium.ttf
  - PlusJakartaSans-SemiBold.ttf, PlusJakartaSans-Bold.ttf

Puis dans `pubspec.yaml`, le dossier `assets/fonts/` est déjà configuré.

## Lancer le projet

```bash
flutter pub get
flutter run
```

## Navigation

| Route        | Écran            |
|--------------|------------------|
| `/`          | Splash           |
| `/onboarding`| Onboarding (3 slides) |
| `/login`     | Connexion        |
| `/register`  | Inscription      |

## Screens générés

1. **Splash** — Gradient violet→orange, logo animé (scale + fade), particules flottantes, texte "INITIALIZING VIRTUAL WORLD"
2. **Onboarding slide 1** — "Your Digital Universe" avec personnages anime stylisés et cityscape
3. **Onboarding slide 2** — "Instant Anime-Style Chat" avec bulles de chat animées
4. **Onboarding slide 3** — "Your Sanctuary Awaits" avec orbe central et avatars en orbite
5. **Login** — Fond gradient lavande, card blanche, champs email/password, lien inscription
6. **Register** — Card avec username/email/password, illustration anime en bas

## Design System

Basé sur le fichier `DESIGN.md` — palette "Lumina Kinetic" :
- **Primary** : `#5E39E0` (Deep Anime Violet)
- **Secondary** : `#674BB5`
- **Accent pink** : `#FF4F8B`
- **Fonts** : Quicksand (headlines) + Plus Jakarta Sans (body)
- **Logo** : Chat bubble custom avec sparkle 4 pointes + notification dot rose
